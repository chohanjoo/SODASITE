package com.tuyano.springboot;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.tuyano.springboot.repositories.MyDataRepository;

@Controller
public class HeloController {

	@Autowired
	MyDataRepository repository;
	
	@Autowired
	MyDataDaoImpl dao;
	
	@Autowired
	MyDataService service;
	
	@Autowired
	MyDataBean myDataBean;
	
	@PostConstruct
	public void init() {
		MyData d1= new MyData();
		d1.setName("kim");
		d1.setAge(30);
		d1.setMail("shin@naver.com");
		d1.setMemo("kim's data");
		repository.saveAndFlush(d1);
		MyData d2= new MyData();
		d2.setName("shin");
		d2.setAge(22);
		d2.setMail("jung@ssu.ac.kr");
		d2.setMemo("shin's data");
		repository.saveAndFlush(d2);
		MyData d3= new MyData();
		d3.setName("lee");
		d3.setAge(35);
		d3.setMail("eun@daum.net");
		d3.setMemo("lee's data");
		repository.saveAndFlush(d3);
	}

	
	@RequestMapping(value = "/" ,method=RequestMethod.GET )
	public ModelAndView index(ModelAndView mav) {
		mav.setViewName("index");
		mav.addObject("msg","this is sample content.");
		Iterable<MyData> list = service.getAll();
		mav.addObject("datalist",list);
		return mav;
	}
	
	@RequestMapping(value="/find", method=RequestMethod.GET)
	public ModelAndView find(ModelAndView mav) {
		mav.setViewName("find");
		mav.addObject("title","Find Page");
		mav.addObject("msg","MyData예제입니다.");
		mav.addObject("value","");
		Iterable<MyData> list = service.getAll();
		mav.addObject("datalist",list);
		return mav;
	}
	
	@RequestMapping(value="/find", method=RequestMethod.POST)
	public ModelAndView search(HttpServletRequest request,ModelAndView mav) {
		mav.setViewName("find");
		String param = request.getParameter("fstr");
		if(param.equals("")) {
			mav = new ModelAndView("redirect:/find");
		}
		else {
			mav.addObject("title","Find result");
			mav.addObject("msg",param+"의 검색결과");
			mav.addObject("value",param);
			List<MyData> list = service.find(param);
			mav.addObject("datalist",list);
		}
		return mav;
	}
	
	@RequestMapping(value="/{id}", method=RequestMethod.GET)
	public ModelAndView indexById(@PathVariable long id,ModelAndView mav) {
		mav.setViewName("pickup");
		mav.addObject("title","Pickup Page");
		String table="<table>"+myDataBean.getTableTagById(id)+"</table>";
		mav.addObject("msg","pickup data id="+id);
		mav.addObject("data",table);
		return mav;
	}
	
	@RequestMapping(value = "/page/{num}", method=RequestMethod.GET)
	public ModelAndView page(@PathVariable Integer num,ModelAndView mav) {
		Page<MyData> page = service.getMyDataInPage(num);
		mav.setViewName("index");
		mav.addObject("title","Find Page");
		mav.addObject("msg","MyData예제입니다");
		mav.addObject("pagenumber","num");
		mav.addObject("datalist",page);
		return mav;
	}
}













