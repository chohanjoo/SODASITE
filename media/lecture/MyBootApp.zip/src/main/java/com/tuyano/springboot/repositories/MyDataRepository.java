package com.tuyano.springboot.repositories;

import java.util.List;
import java.util.Optional;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.tuyano.springboot.MyData;

@Repository
public interface MyDataRepository  extends JpaRepository<MyData, Long> {

	@Query("select d from MyData d order by d.name")
	List<MyData> findAllOrderByName();
	
	@Query("from MyData where age> :min and age< :max")
	public List<MyData> findByAge(@Param("min") int min,@Param("max") int max);

	@Query("from MyData where id = :id")
	public MyData findOne(@Param("id") Long id);
}