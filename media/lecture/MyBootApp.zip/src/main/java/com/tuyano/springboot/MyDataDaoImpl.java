package com.tuyano.springboot;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.loader.criteria.CriteriaLoader;
import org.springframework.stereotype.Repository;

@Repository
public class MyDataDaoImpl implements MyDataDao<MyData> {
	private static final long serialVersionUID = 1L;

	@PersistenceContext
	private EntityManager entityManager;
	
	public MyDataDaoImpl() {
		super();
	}
	
	public MyDataDaoImpl(EntityManager manager) {
		entityManager = manager;
	}
	
	@Override
	public List<MyData> getAll() {
		int start=1;	//추출 위치
		int limit=2;	//추출 개수
		List<MyData> list = null;
		CriteriaBuilder builder=entityManager.getCriteriaBuilder();
		CriteriaQuery<MyData> query = builder.createQuery(MyData.class);
		Root<MyData> root = query.from(MyData.class);
		query.select(root).orderBy(builder.asc(root.get("id")));
		list = (List<MyData>)entityManager.createQuery(query).setFirstResult(start).setMaxResults(limit).getResultList();
		return list;
	}

	@Override
	public MyData findById(long id) {
		return (MyData)entityManager.createQuery("from MyData where id=" + id).getSingleResult();
	}

	@Override
	public List<MyData> findByName(String name) {
		return (List<MyData>)entityManager.createQuery("from MyData where name=" + name).getResultList();
	}

	@Override
	public List<MyData> find(String fstr) {
		//Query(JPQL) 사용 방법
		/*List<MyData> list=null;
		Long fid =0L;
		try {
			fid = Long.parseLong(fstr);
		}catch(NumberFormatException e) {
			e.printStackTrace();
		}
		Query query = entityManager.createQuery("findWithName").setParameter("fname", "%"+fstr+"%");
		list = query.getResultList();
		return list;*/
		
		// Criteria사용 방법
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<MyData> query = builder.createQuery(MyData.class);
		Root<MyData> root = query.from(MyData.class);
		query.select(root).where(builder.equal(root.get("name"),fstr));
		List<MyData> list = null;
		list = (List<MyData>)entityManager.createQuery(query).getResultList();
		return list;
	}

}


